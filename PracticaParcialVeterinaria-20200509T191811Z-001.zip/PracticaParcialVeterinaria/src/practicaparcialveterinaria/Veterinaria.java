package practicaparcialveterinaria;

public class Veterinaria {

    private final Cliente[] c;

    public Veterinaria(int cantidad) {
        c = new Cliente[cantidad];
    }

    public void agregarCliente(Cliente x) {
        for (int i = 0; i < c.length; i++) {
            if (c[i] == null) {
                c[i] = x;
                break;
            }
        }
    }
    
    public int cantidadClientes() {
        int contador = 0;
        for (int i = 0; i < c.length; i++) {
            if (c[i] != null) {
                contador++;
            }
        }
        return contador;
    }
    
    public int cliMayCincoAnios() {
        int con = 0;
        for (Cliente cli : c) {
            if (cli != null && cli.getAntiguedad() >= 5) {
                con++;
            }
        }
        return con;
    }
    
    public String listadoClientes() {
        String cadena = "";
        for (int i = 0; i < c.length; i++) {
            if (c[i] != null) {
                cadena += c[i].getNombre();
            }
        }
        return cadena;
    }
    
    public float promedioEdadMascotas() {
        float acu = 0;
        int cont = 0;
        for (int i = 0; i < c.length; i++) {
            if (c[i] != null) {
                acu += c[i].edadMascota();
                cont++;
            }
        }
        return (float)acu/cont;
    }

    @Override
    public String toString() {
        return "Veterinaria{" + "c=" + listadoClientes() + '}';
    }
}
