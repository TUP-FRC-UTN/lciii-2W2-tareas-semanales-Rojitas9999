
package practicaparcialveterinaria;

public class Cliente {
    private String nombre;
    private int antiguedad;
    private int numCliente;
    private Mascota m;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    public int getNumCliente() {
        return numCliente;
    }

    public void setNumCliente(int numCliente) {
        this.numCliente = numCliente;
    }

    public Cliente(String nombre, int antiguedad, int numCliente) {
        this.nombre = nombre;
        this.antiguedad = antiguedad;
        this.numCliente = numCliente;
    }
    
    public void agregarMascota(Mascota x) {
        m = x;
    }
    
    public int edadMascota(){
        return m.getEdad();
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", antiguedad=" + antiguedad + ", mascota=" + m.getNombre() + '}';
    }
    
}
