package practicaparcialveterinaria;

import java.util.Scanner;

public class PracticaParcialVeterinaria {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("¿Cuantos clientes quiere agregar a la veterinaria?");
        int cantCli = sc.nextInt();

        Veterinaria v = new Veterinaria(cantCli);

        for (int i = 0; i < cantCli; i++) {
            System.out.println("Por favor ingrese el N° del cliente " + (i+1));
            int num = sc.nextInt();
            System.out.println("Ahora su nombre");
            sc.nextLine();
            String nom = sc.nextLine();
            System.out.println("¿Hace cuantos años que " + nom + " es nuestro cliente?");
            int ant = sc.nextInt();

            Cliente c = new Cliente(nom, ant, num);

            sc.nextLine();
            System.out.println("Ahora el nombre de la mascota de " + c.getNombre());
            String nomMas = sc.nextLine();
            System.out.println("Y la edad de " + nomMas);
            int edadMas = sc.nextInt();

            Mascota m = new Mascota(nomMas, edadMas);
            
            c.agregarMascota(m);
            v.agregarCliente(c);
        }
        System.out.println("Listado de clientes: " + v.listadoClientes());
        System.out.println("Promedio de edad de las mascotas: " + v.promedioEdadMascotas());
        System.out.println("Clientes con antiguedad mayor o igual a 5 años: " + v.cliMayCincoAnios());
    }
}