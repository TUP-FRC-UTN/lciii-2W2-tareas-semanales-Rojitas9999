package practicoparcialbiblioteca;

import java.util.Scanner;

public class PracticoParcialBiblioteca {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Biblioteca b = new Biblioteca(1);
        System.out.println("¿Que cantidad de libros va a ingresar?");
        int cantLibros = sc.nextInt();
        b.cantidadLibros(cantLibros);
        Libro[] l;
        l = new Libro[cantLibros];
        for (int i = 0; i < cantLibros; i++) {
            sc.nextLine();
            System.out.println("Ingrese el titulo del libro");
            l[i].setTitulo(sc.nextLine());
            System.out.println("Ingrese su precio");
            l[i].setPrecio(sc.nextInt());
            int est;
            do {
                System.out.println("Ahora ingrese su estado:" + "\n" + "1 para Disponible" + "\n" + "2 para Prestado" + "\n" + "3 para Extraviado");
                est = sc.nextInt();
            } while (est != 1 && est != 2 && est != 3);
            l[i].setEstado(est);
            sc.nextLine();
            System.out.println("¿Quien solicita el libro");
            String pres = sc.nextLine();
            System.out.println("¿Por cuantos dias?");
            int dias = sc.nextInt();
            System.out.println("¿Fue devuelto?" + "\n" + "1 para si" + "\n" + "2 para no");
            int devu = sc.nextInt();
            boolean dev = false;
            if (devu == 1) {
                dev = true;
            }
            Prestamo p = new Prestamo(pres, dias, dev);
            l[i].agregarPrestamo(p);
            b.agregarLibro(l[i]);
        }
        System.out.println(" Ingrese el título del libro a buscar : ");
        String tituloBuscado = sc.next();
        System.out.println(" RESULTADOS ");
        System.out.println(" Cantidad de libros disponibles : " + b.cantidadLibros(1));
        System.out.println(" Cantidad de libros prestados : " + b.cantidadLibros(2));
        System.out.println(" Cantidad de libros extraviados : " + b.cantidadLibros(3));
        System.out.println(" Suma de los precios de los extraviados : " + b.sumaPrecioExtraviados());
        System.out.println(" Solicitantes del libro " + tituloBuscado + " : " + b.listadoSolicitantes(tituloBuscado));
        System.out.println(" Promedio general de prestamos : " + b.promedioPrestamos());
    }
}