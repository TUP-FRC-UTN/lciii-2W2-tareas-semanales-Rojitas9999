package practicoparcialbiblioteca;

public class Libro {

    private String titulo;
    private int precio;
    private int estado;
    private Prestamo[] p;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public Libro(String titulo, int precio, int estado) {
        this.titulo = titulo;
        this.precio = precio;
        this.estado = estado;
    }

    public Libro(int cantidad) {
        p = new Prestamo[cantidad];
    }

    public void agregarPrestamo(Prestamo a) {
        for (int i = 0; i < p.length; i++) {
            if (p[i] == null) {
                p[i] = a;
                break;
            }
        }
    }

    public String listadoSolicitantes() {
        String cadena = "";
        for (Prestamo x : p) {
            cadena = x.getSolicitante() + "\n";
        }
        return cadena;
    }

    public int cantidadPrestamos() {
        int c = 0;
        for (int i = 0; i < p.length; i++) {
            if(p[i] != null)
                c++;
        }
        return c;
    }

    public String estado() {
        switch (estado) {
            case 1:
                return "Disponible";
            case 2:
                return "Prestado";
            default:
                return "Extraviado";
        }
    }
    
    @Override
    public String toString() {
        return "Libro{" + "titulo=" + titulo + ", precio=" + precio + ", estado=" + estado + '}';
    }
}