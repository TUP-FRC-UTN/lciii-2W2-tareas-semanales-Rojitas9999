package practicoparcialbiblioteca;

public class Biblioteca {

    private final Libro[] lib;

    public Biblioteca(int cantLibros) {
        lib = new Libro[cantLibros];
    }

    public void agregarLibro(Libro a) {
        for (int i = 0; i < lib.length; i++) {
            if (lib[i] == null) {
                lib[i] = a;
                break;
            }
        }
    }
    
    public int cantidadLibros(int estado) {
        int c = 0;
        for (Libro x : lib) {
            if (x != null && x.getEstado() == estado) {
                c++;
            }
        }
        return c;
    }
    
    public int[] cantidadLibrosPorEstado() {
        int c[] = new int[3];
        for (int i : c) {
            i = 0;
        }      
        for (Libro x : lib) {
            if (x != null) {
                switch (x.getEstado()) {
                    case 1:
                        c[0]++;
                        break;
                    case 2:
                        c[1]++;
                        break;
                    default:
                        c[2]++;
                        break;
                }
            }
        }
        return c;
    }
    
    public String listadoSolicitantes(String titulo) {
        String lista = "No hay coincidencias";
        for (Libro a : lib) {
            if (a != null && a.getTitulo().equalsIgnoreCase(titulo)) {
                lista = a.listadoSolicitantes();
            }
        }
        return lista;
    }
    
    public float promedioPrestamos() {
        float prom = 0;
        for (Libro x : lib) {
            prom += (float)lib.length / x.cantidadPrestamos();
        }
        return prom;
    }
    
    public float sumaPrecioExtraviados() {
        float suma = 0;
        for (Libro x : lib) {
            if (x != null && x.getEstado() == 3) {
                suma += x.getPrecio();
            }
        }
        return suma;
    }
}
