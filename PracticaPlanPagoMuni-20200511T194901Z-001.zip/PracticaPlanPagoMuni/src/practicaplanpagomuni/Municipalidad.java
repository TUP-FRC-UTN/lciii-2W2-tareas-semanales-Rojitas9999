package practicaplanpagomuni;

public class Municipalidad {

    Plan[] p;

    public Municipalidad(int c) {
        p = new Plan[c];
    }

    public void agregarPlan(Plan x) {
        for (int i = 0; i < p.length; i++) {
            if (p[i] == null) {
                p[i] = x;
                break;
            }
        }
    }

    public int cantidadPlanesPagados() {
        int c = 0;
        for (Plan plan : p) {
            if (plan != null && plan.estaPagadoTotalmente()) {
                c++;
            }
        }
        return c;
    }

    public float sumatoriaDeuda() {
        float total = 0;
        for (Plan plan : p) {
            if (plan != null) {
                total += plan.getDeuda();
            }
        }
        return total;
    }

    public String listaPagosContribuyente(String n) {
        String cadena = "";
        for (Plan plan : p) {
            if (plan != null && plan.getNombre().equalsIgnoreCase(n)) {
                cadena += plan.listadoPagos();
            }
        }
        return cadena;
    }

    public float promedioIntereses() {
        float promedio = 0;
        float acu = 0;
        int c = 0;
        for (Plan plan : p) {
            if (plan != null) {
                acu += plan.sumaInteresesCobrados();
                c++;
            }
        }
        if (c != 0) {
            promedio = (float) acu / c;
        }
        return promedio;
    }
}
