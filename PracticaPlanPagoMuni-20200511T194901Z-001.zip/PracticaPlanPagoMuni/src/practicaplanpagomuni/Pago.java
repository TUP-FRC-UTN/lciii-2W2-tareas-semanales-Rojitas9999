
package practicaplanpagomuni;

public class Pago {
    private int demora;
    private float importe;
    private final float intereses;

    public Pago(int demora, float importe) {
        this.demora = demora;
        this.importe = importe;
        if (demora == 0) {
            this.intereses = 0;
        } else {
            this.intereses = importe * 0.005f * demora;
        }
    }

    public int getDemora() {
        return demora;
    }

    public void setDemora(int demora) {
        this.demora = demora;
    }

    public float getImporte() {
        return importe;
    }

    public void setImporte(float importe) {
        this.importe = importe;
    }

    public float getIntereses() {
        return intereses;
    }

    @Override
    public String toString() {
        return "Plan{" + "demora=" + demora + ", importe=" + importe + ", intereses=" + intereses + '}';
    }
}
