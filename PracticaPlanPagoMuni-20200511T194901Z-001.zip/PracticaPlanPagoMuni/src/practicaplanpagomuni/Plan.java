
package practicaplanpagomuni;

public class Plan {
    private String nombre;
    private float deuda;
    private int cuotas;
    private final Pago[] pagos;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getDeuda() {
        return deuda;
    }

    public void setDeuda(float deuda) {
        this.deuda = deuda;
    }

    public int getCuotas() {
        return cuotas;
    }

    public void setCuotas(int cuotas) {
        this.cuotas = cuotas;
    }

    public Plan(String nombre, float deuda, int cuotas, int c) {
        this.nombre = nombre;
        this.deuda = deuda;
        this.cuotas = cuotas;
        pagos = new Pago[c];
    }
    
    public void agregarPago(Pago p) {
        for (int i = 0; i < pagos.length; i++) {
            if (pagos[i] == null) {
                pagos[i] = p;
                break;
            }
        }
    }
    
    public boolean estaPagadoTotalmente() {
        int c = 0;
        for (int i = 0; i < pagos.length; i++) {
            if (pagos[i] == null) {
                c++;
            }
        }
        return cuotas == c;
    }
    
    public String listadoPagos() {
        String cadena = "";
        for (Pago p : pagos) {
            cadena += p.toString() + "\n";
        }
        return cadena;
    }
    
    public float sumaInteresesCobrados() {
        float acu = 0;
        for (Pago p : pagos) {
            if (p != null) {
                acu += p.getIntereses();
            }
        }
        return acu;
    }
}