package practicaplanpagomuni;

import java.util.Scanner;

public class PracticaPlanPagoMuni {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("¿Cuantos planes desea cargar?");
        int cantPlanes = sc.nextInt();

        Municipalidad muni = new Municipalidad(cantPlanes);

        for (int i = 0; i < cantPlanes; i++) {
            sc.nextLine();
            System.out.println("Nombre del contribuyente del plan " + (i + 1));
            String nom = sc.nextLine();
            System.out.println("Total de su deuda");
            float deu = sc.nextFloat();
            System.out.println("Cantidad de cuotas en total");
            int cantCuotas = sc.nextInt();
            System.out.println("Cantidad de cuotas pagadas");
            int cantCuotasPagadas = sc.nextInt();

            Plan plan = new Plan(nom, deu, cantCuotas, cantCuotasPagadas);

            for (int j = 0; j < cantCuotasPagadas; j++) {
                System.out.println("Dias de demora del pago de la cuota " + (j + 1));
                int dem = sc.nextInt();
                System.out.println("Importe pagado");
                float importe = sc.nextFloat();

                Pago pago = new Pago(dem, importe);
                plan.agregarPago(pago);
            }
            muni.agregarPlan(plan);
        }
        sc.nextLine();
        System.out.println("Ingrese el nombre del contribuyente que desee buscar");
        String n = sc.nextLine();
        System.out.println("Todos los pagos efectuados por " + muni.listaPagosContribuyente(n));
        System.out.println("Planes pagados en total: " + muni.cantidadPlanesPagados());
        System.out.println("Total de deudas: " + muni.sumatoriaDeuda());
        System.out.println("Promedio general de los intereses: " + muni.promedioIntereses());
    }
}
